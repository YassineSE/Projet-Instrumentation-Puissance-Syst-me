/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
typedef struct {
    float Kp;    // Gain proportionnel
    float Ki;    // Gain intégral
    float Kd;    // Gain dérivé
    float setpoint;   // Consigne
    float integrator; // Terme intégral accumulé
    float previous_error; // Erreur précédente pour la dérivée
    float output;   // Sortie du PID
} PID_Controller;

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim1;

USART_HandleTypeDef husart2;

/* USER CODE BEGIN PV */
uint16_t dma_buffer[2];


#define RX_BUFFER_SIZE 64 // Taille du buffer de réception

char* rx_buffer[RX_BUFFER_SIZE]; // Déclaration du buffer de réception

PID_Controller pid;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM1_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void PID_Init(PID_Controller *pid, float Kp, float Ki, float Kd)
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->integrator = 0.0f;
    pid->previous_error = 0.0f;
    pid->output = 0.0f;
}

float PID_Compute1(PID_Controller *pid, float current_value)
{
    float error = pid->setpoint - current_value;
    pid->integrator += error; // Calcul du terme intégral
    float derivative = error - pid->previous_error; // Calcul du terme dérivé
    pid->output = (pid->Kp * error) + (pid->Ki * pid->integrator) + (pid->Kd * derivative);
    pid->previous_error = error; // Met à jour l'erreur précédente
    return pid->output;
}
float get_tension(float temperature)
{
    float vdsortie = 31*3.3*(((158.33*exp(-0.048*temperature))/(158.33*exp(-0.048*temperature)+4700)));
    return vdsortie;
}
float get_resistance(float tension){
	float resistance = (4700*((tension)/(3.3)+(10)/(10*4700)))/(1-(tension)/(3.3)-(10)/(10+4700));
	return resistance;
}
// Données : Température (°C) et Ratio (RT / R25)
double temperature[] = {-55.0, -50.0, -45.0, -40.0, -35.0, -30.0, -25.0, -20.0, -15.0, -10.0, -5.0, 0.0,
                        5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0, 55.0, 60.0, 65.0, 70.0,
                        75.0, 80.0, 85.0, 90.0, 95.0, 100.0, 105.0, 110.0, 115.0, 120.0, 125.0, 130.0, 135.0,
                        140.0, 145.0, 150.0, 155.0};
double resistance_ratio[] = {103.81, 73.707, 52.723, 37.988, 27.565, 20.142, 14.801, 10.976, 8.1744, 6.1407,
                             4.6331, 3.5243, 2.6995, 2.0831, 1.6189, 1.2666, 1.0, 0.78351, 0.62372, 0.49937,
                             0.40218, 0.32557, 0.26402, 0.21527, 0.17693, 0.14616, 0.12097, 0.10053, 0.083761,
                             0.070039, 0.058937, 0.049777, 0.042146, 0.035803, 0.030504, 0.026067, 0.022332,
                             0.019186, 0.016515, 0.014253, 0.012367, 0.010758, 0.0093933};
int data_size = sizeof(temperature) / sizeof(temperature[0]);

// Fonction d'interpolation linéaire
double interpolate(double x, double x_vals[], double y_vals[], int size) {
    if (x <= x_vals[size - 1]) {
        for (int i = 0; i < size - 1; i++) {
            if (x >= x_vals[i + 1]) {
                double t = (x - x_vals[i]) / (x_vals[i + 1] - x_vals[i]);
                return y_vals[i] + t * (y_vals[i + 1] - y_vals[i]);
            }
        }
    }
    // Extrapolation pour les valeurs hors de la plage
    if (x > x_vals[0]) return y_vals[0];
    return y_vals[size - 1];
}

// Fonction pour convertir une résistance mesurée en température
double resistance_to_temperature(double R_measured) {
    double R25 = 47000.0; // Résistance à 25°C en Ohms
    double beta = 4450;
    float T0 = 298;
    float T= 1 / ((1/T0)+ (1/ beta) * log(R_measured/R25));
    return T-273.15;
}
// Callback pour réception
/*
void HAL_USART_RxCpltCallback(USART_HandleTypeDef *husart) {
    if (husart->Instance == USART3) {
        // Traitement des données reçues
    	pid.setpoint=get_tension(atof(rx_buffer));
        // Relancer la réception
        HAL_UART_Receive_IT(&husart2, rx_buffer, RX_BUFFER_SIZE);
    }
}*/
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM1_Init();
  MX_ADC1_Init();
  MX_USART2_Init();
  /* USER CODE BEGIN 2 */
  PID_Init(&pid, 1, 0.5, 2);
  HAL_ADC_Start(&hadc1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  // Par exemple, pour définir un duty cycle de 50 % sur le canal 1
  uint32_t new_duty_cycle = 50; // en pourcentage
  uint32_t max_value = __HAL_TIM_GET_AUTORELOAD(&htim1); // Valeur d'auto-reload du timer
  uint32_t compare_value = (new_duty_cycle * max_value) / 100;
  float i =0.0;
  float i_step = 1.0;
  float pid_output_limited;
  float previous_pidoutput = 0;
  float setpoint = 0;
  float pid_max = resistance_to_temperature(15000);
  float pid_min = resistance_to_temperature(60000);
  float consigneTemperature = 23;
  pid.setpoint = consigneTemperature;
  // Mettre à jour le registre de comparaison pour ajuster le duty cycle
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
  char buffer[100];
  char bufferVolt[100];
  float voltage0;
  float voltage1;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  HAL_ADC_Start_DMA(&hadc1,(uint32_t *)dma_buffer,2);

	  unsigned long adc_value0 = dma_buffer[0];
	  voltage0 = (adc_value0 *3.3f) /4095.0f;
	  //sprintf(buffer,"IN0 : %8.6f\r\n",voltage0);
	  HAL_USART_Transmit(&husart2, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);


	  unsigned long adc_value1 = dma_buffer[1];
	  voltage1 = (adc_value1 *3.3f) /4095.0f;
	  float resistance= get_resistance(voltage1);
	  sprintf(bufferVolt,"Tension : %8.6f\r\n",voltage1);
	  sprintf(buffer,"Resistance : %8.6f\r\n",resistance);

	  HAL_USART_Transmit(&husart2, (uint8_t*)bufferVolt, strlen(buffer), HAL_MAX_DELAY);
	  HAL_USART_Transmit(&husart2, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
	  //
	  double temperature_result = resistance_to_temperature(resistance);

	  sprintf(buffer,"Temperature : %8.6f\r\n",temperature_result);
	  HAL_USART_Transmit(&husart2, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
	  float pid_input = temperature_result;
	  float pid_output = PID_Compute1(&pid, pid_input); // Calcul de la sortie du PID
	  //pid_output = pid_output/100;
	  // Convertit la s ortie du PID pour ajuster la PWM (il faut que pid_output soit dans les limites du rapport cyclique)

	  if (pid_output < pid_min) pid_output = pid_min;
	  if (pid_output > pid_max) pid_output = pid_max; // Limite le rapport cyclique entre 0 et 100%

	  //sprintf(buffer,"Pid_Output : %8.6f\r\n",pid_output);
	  //HAL_USART_Transmit(&husart2, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
	  float duty_cycle = (pid_output - pid_min) / (pid_max - pid_min) * 100;

	  // Assurer que le duty cycle reste dans [0, 100]
	  if (duty_cycle > 100.0) duty_cycle = 100.0;
	  if (duty_cycle < 0.0) duty_cycle = 0.0;
	  // en pourcentage
	  sprintf(buffer,"Duty cycle : %8.6f\r\n",duty_cycle);
	  HAL_USART_Transmit(&husart2, (uint8_t*)buffer, strlen(buffer), HAL_MAX_DELAY);
	  max_value = __HAL_TIM_GET_AUTORELOAD(&htim1); // Valeur d'auto-reload du timer
	  compare_value = (duty_cycle * max_value) / 100.0;
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
	  //__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, compare_value);


	  HAL_Delay(10);
	    /*
	  i+= i_step;
	  if (i == 1000){
		  i_step = -1;
	  }
	  else if (i == 0) {
		  i_step = 1;
	  }*/

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 2;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 89;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 9999;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_OC_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_OC2REF;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 4000;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_ACTIVE;
  sConfigOC.Pulse = 3333;
  if (HAL_TIM_OC_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  husart2.Instance = USART2;
  husart2.Init.BaudRate = 115200;
  husart2.Init.WordLength = USART_WORDLENGTH_8B;
  husart2.Init.StopBits = USART_STOPBITS_1;
  husart2.Init.Parity = USART_PARITY_NONE;
  husart2.Init.Mode = USART_MODE_TX_RX;
  husart2.Init.CLKPolarity = USART_POLARITY_LOW;
  husart2.Init.CLKPhase = USART_PHASE_1EDGE;
  husart2.Init.CLKLastBit = USART_LASTBIT_DISABLE;
  if (HAL_USART_Init(&husart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void ADC_Select_CH0 (void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
	  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	  */
	  sConfig.Channel = ADC_CHANNEL_1;
	  sConfig.Rank = 1;
	  //sConfig.SamplingTime = ADC_SAMPLETIME_28CYCLES;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
}

void ADC_Select_CH1 (void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
	  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	  */
	  sConfig.Channel = ADC_CHANNEL_0;
	  sConfig.Rank = 1;
	  //sConfig.SamplingTime = ADC_SAMPLETIME_84CYCLES;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc1){
	HAL_ADC_Stop_DMA(hadc1);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
